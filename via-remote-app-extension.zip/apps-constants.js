// Shared app constants for background and content scripts
const allApps = [
  {
    id: 1,
    app: "Rp",
    label: "Ride Plan",
    key: "ride-plan",
    path: "/planning/ride-planner",
  },
  {
    id: 2,
    app: "Neo",
    label: "Neo",
    key: "via-hub-dev",
    path: "/network-optimizer",
  },
  {
    id: 5,
    app: "Sm",
    label: "Shift Manager",
    key: "shift-manager",
    path: "/shift-manager",
  },
  {
    id: 3,
    app: "Fl",
    label: "Flexity",
    key: "configuration-service",
    path: "/configuration-service",
  },
];

// Make it available globally for background and content scripts
if (typeof window !== 'undefined') {
  // Content script context
  window.allApps = allApps;
} else if (typeof global !== 'undefined') {
  // Background script context
  global.allApps = allApps;
} 